IcnsOSX: README
October 21, 2007


IcnsOSX is a set of replacement icons for Mini vMac
to use in Macintosh OS X.

Further information may be found at
"http://minivmac.sourceforge.net/extras/icons.html".

These icons are copyright (C) 2007 David Sibley.
("http://www.mac128.com/")

You can redistribute IcnsOSX and/or modify it under the terms
of version 2 of the GNU General Public License as published by
the Free Software Foundation.  See the included file COPYING.

IcnsOSX is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
license for more details.
