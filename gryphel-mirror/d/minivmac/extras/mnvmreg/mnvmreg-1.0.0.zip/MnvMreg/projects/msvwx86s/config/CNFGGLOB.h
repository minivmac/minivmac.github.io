/* make sure this is correct CNFGGLOB */
#ifndef _MSC_VER
#error "wrong CNFGGLOB.h"
#endif
#ifndef _M_IX86
#error "wrong CNFGGLOB.h"
#endif

/* --- set up compiler options --- */

/* ignore integer conversion warnings */
#pragma warning(disable : 4244 4761 4018 4245 4024 4305)

/* ignore unused inline warning */
#pragma warning(disable : 4514)

/* ignore type redefinition warning */
#pragma warning(disable : 4142)

