/* make sure this is correct CNFGGLOB */
#ifndef __LCC__
#error "wrong CNFGGLOB.h"
#endif

#define UnusedParam(x)
