/* make sure this is correct CNFGGLOB */
