MnvMreg README
Paul C. Pratt
www.gryphel.com
March 24, 2004

MnvMreg is a utility to install Mini vMac
into the Microsoft Windows registry, so that
double clicking on a disk image file with
the extension '.dsk' will open it with Mini
vMac, and so that such disk image files and
also '.rom' files will be displayed with
custom icons.

Prior to version 1.0.0 of Mini vMac,
every launch of the Mini vMac application
would reinstall it in the registry.
But since this could conflict with other
applications that want to use the '.dsk'
and '.rom' extensions, this feature
was removed. MnvMreg brings this
back as a 'use at your own risk'
optional feature.

To use MnvMreg, move 'MnvMreg.exe'
application into the same folder as
'minivmac.exe' that you want to use.
Then double click on it to launch it.
It should give a confirmation dialog
to indicate it succeeded, and then
quit. If it fails, it should display
a dialog with a brief error message.

If you move the Mini vMac application,
you will need to run MnvMreg again.

--

You can redistribute this folder and/or modify it under the terms
of version 2 of the GNU General Public License as published by
the Free Software Foundation.  See the included file COPYING.

Mini vMac is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
license for more details.

--

MnvMreg can be compiled with Microsoft Visual C++ 6,
the lcc-win32 system, or Bloodshed Dev-C++, using a
method similar to that documented for Mini vMac.
