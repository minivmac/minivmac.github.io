Read Me: Mini vMac Retro Icon.

General Info:
I’ve designed, illustrated, and created a vintage Macintosh computer in classic pixel icon style as a modern (OSX) .icns icon file with the file name “vMac_Retro_Icon.icns”. I’ve included an exact copy of said file with the file name, “AppIcon.icns” for use as a software icon for Mini vMac.

The .icns file includes all currently supported (as of July 2014) OSX icon sizes including retina display sizes.

16x16
16x16@2x
32x32
32x32@2x
128x128
128x128@2x
256x256
256x256@2x
512x512
512x512@2x (this is also serves as the 1024x1024)

If interested I could create icons for Mini vMac running on any other platforms, i.e. Microsoft Windows and/or Linux.

Author:
Joseph V. Barrile | http://www.barrile.com | http://www.behance.net/JosephBarrile | http://barrileart.tumblr.com/

Copying/License:
I’m offering this as free software to be used as an application icon for Paul C. Pratt and his Mini vMac software project (http://minivmac.sourceforge.net) only and may not be sold or repackaged in any other manner. Joseph V. Barrile must be identified as the author of this work.